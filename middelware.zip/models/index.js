import {detailsmodel} from "../models/userdetails";
const dbmodel = {};
dbmodel.detailsmodel = detailsmodel;
module.exports = dbmodel;